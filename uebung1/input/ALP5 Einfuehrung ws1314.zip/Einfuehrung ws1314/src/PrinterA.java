
public class PrinterA extends Printer {
	@Override
	public void print() {
		System.out.println("A");
	}
}
