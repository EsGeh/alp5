
public class PrinterB extends Printer {
	@Override
	public void print() {
		System.out.println("B");
	}
}
